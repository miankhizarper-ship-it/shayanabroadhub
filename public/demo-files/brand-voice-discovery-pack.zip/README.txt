Brand Voice Discovery Pack

Five exercises that turn 'make it sound premium' into language your team can use.

1. The specific-sentence drill
2. The refusal list
3. The read-aloud test
4. The two-adjective rule
5. The enemy statement

Sample file generated for the demo library.